<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- link for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- link for favicon -->
    <link rel="icon" type="image/x-icon" href="images/favicon.jpeg">
    <style>
        *{
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    border: border-box;    
}

.navbar{
    height: 55px;
    background-color: #FF69B4;
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-evenly;
}

.nav-address{
    margin-right: 50px;
}

.nav-address:hover{
    border: 2px solid ;
}

.nav-logo{
    height: 50px;
    width: 100px;
}

.logo{
    background-image: url("imagesUsed/meesho_logo.jpeg");
    background-size: cover;
    height: 50px;
    width: 100%;
}

.border{
    border: 2px solid transparent;
}

.border:hover{
    border: 2px solid ;
}

/* box2 */

.add-first{
    color: #cccccc;
    font-size: 0.85 rem;
    margin-left: 15px;
}

.add-second{
    font-size: 1 rem;
    margin-left: 3px;
}

.add-icon{
    display: flex;
    align-items: center;
}

/* box3 */
.nav-search{
    display: flex;
    justify-content: space-evenly;
    background-color: pink;
    width: 620px;
    height: 40px;
    border-radius: 4px;
}

.search-select{
    background-color: #f3f3f3;
    width: 50px;
    text-align: center;
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
    border: none;
}

.search-input{
    width: 100%;
    font-size: 1 rem;
    border: none;
}

.search-icon{
    width: 45px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 1.2 rem;
    background-color:#febd68;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
    color: #0f1111;
}

.nav-search:hover{
    border: 2px solid orange;
}

/* box 4 */

span{
    font-size: 0.7 rem;

}

.nav-second{
    font-size: 0.85 rem;
    font-weight: 700;
}

/* box6 */
.nav-cart i{
    font-size: 30px;

}

.nav-cart{
    font-size: 0.85 rem;
    font-weight: 700;
}

/* Mobile links */

.mobile-nav {
    display: none;
    flex-direction: column;
    background-color: #131921;
    color: white;
}

.mobile-nav.show {
    display: flex;
}


.mobile-nav .nav-item {
    padding: 10px;
    border-bottom: 1px solid #333;
    cursor: pointer;
}

.mobile-nav .nav-item:hover {
    background-color: #333;
}



/* Panel */

.panel{
    height: 40px;
    background-color: #222f3d;
    display: flex;
    color: white;
    align-items: center;
    justify-content: space-evenly;
}

.panel-ops p{
    display: inline;
    margin-left: 10px;
}

.panel-ops{
    width: 70%;
    font-size: 0.85 rem;
}

.panel-deals{
    font-size: 0.9 rem;
    font-weight: 700;
}

.panelLinks{
    color: white;
    text-decoration: none;
}

.panelLinks:hover{
    text-decoration: underline;
}

.shop-section{
    display: flex;
    justify-content: space-evenly;
    background-color: #e2e7e6;
}

.box{
    height: 400px;
    border: 2px solid black;
    width: 23%;
    background-color: white;
}

.hero-section{
    margin-top: 15px;
}

    </style>

    <title>My Meesho HomePage</title>
</head>
<body>
   <!-- Page Header -->
   <header>
    <div class="navbar">
        <div class="nav-logo border">
            <div class="logo"></div>
        </div>

        <div class="nav-address">
            <p class="add-first">Deliver to</p>
            <div class="add-icon">
                <i class="fa-solid fa-location-dot"></i>
                <P class="add-second">Canada</P>
            </div>
        </div>

        <div class="nav-search">
            <select class="search-select">
                <option>All items</option>
            </select>
            <input class="search-input"  placeholder="Search Meesho">
            <div class="search-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
        </div>

        <div class="nav-signin border">
            <p class="nav-second"> Account & Lists</p>
        </div>

        <div class="nav-return border">
            <p><span>Returns</span></p>
            <p class="nav-second"> & Orders</p>
        </div>

        <div class="nav-cart border">
            <i class="fa-solid fa-cart-shopping"></i>
            Cart
        </div>

    </div>

    <!-- mobile navigation links -->
    <div class="mobile-nav" id="mobileNav">
        <div class="nav-item"><p class="add-first">Deliver to Canada</p></div>
        <div class="nav-item"><p><span>Hello, sign in</span></p><p class="nav-second"> Account & Lists</p></div>
        <div class="nav-item"><p><span>Returns</span></p><p class="nav-second"> & Orders</p></div>
       
    </div>

    <!-- page panel -->
        <div class="panel">
            <div class="panel-all">
                <i class="fa-solid fa-bars"></i>
                All
            </div>

        <div class="panel-ops">
            <p><a href="homepage.html" class="panelLinks">Home</a></p>    
            <p><a href="index.html" class="panelLinks">Product</a></p>     
            <p><a href="about.html" class="panelLinks">About us</a></p>     
            <p><a href="contact.html" class="panelLinks">Contact us</a></p>  
        </div>
        <div class="panel-deals">
            Shop amazing deals
        </div>
    </div>
    </header>

    <!-- Page main  -->
    <!-- Page hero section -->
    <div class="hero-section">
        <div class="hero-message">
            <P>You are on meesho.com. You can also shop on Meesho Canada for millions of products with fast local delivery</P>
        </div>
    </div>